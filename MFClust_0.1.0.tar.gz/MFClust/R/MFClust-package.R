## usethis namespace: start
#' @useDynLib MFClust, .registration = TRUE
#'@importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
